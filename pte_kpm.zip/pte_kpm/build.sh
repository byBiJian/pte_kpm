#!/data/data/com.termux/files/usr/bin/sh
# pte_kpm 一键编译脚本（在 termux 里执行: sh build.sh）
export KP_DIR=/data/user/0/com.termux/files/home/KernelPatch
export NDK_BIN=/data/user/0/com.termux/files/home/android-ndk-r29/toolchains/llvm/prebuilt/linux-aarch64/bin
cd "$(dirname "$0")" || exit 1
make clean >/dev/null 2>&1
make
echo "----"
ls -la pte_kpm.kpm
