/* 并发压力测试: ls=2线程屏障同步(最坏重叠) ; h4=4线程满速
 * 每线程 N=20000 次调用 demo_add，预期精确 N*线程数 命中 */
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
extern int demo_add(int a, int b);
#define N 20000
static pthread_barrier_t bar;

static void *thr_ls(void *arg) {
    long id = (long)arg; long s = 0;
    for (int i = 0; i < N; i++) {
        pthread_barrier_wait(&bar);
        s += demo_add((int)id, i);
    }
    printf("t%ld s=%ld\n", id, s); fflush(stdout); return 0;
}
static void *thr_free(void *arg) {
    long id = (long)arg; long s = 0;
    for (int i = 0; i < N; i++) s += demo_add((int)id, i);
    printf("t%ld s=%ld\n", id, s); fflush(stdout); return 0;
}
int main(int argc, char **argv) {
    const char *m = argc > 1 ? argv[1] : "ls";
    printf("mode=%s N=%d\n", m, N); fflush(stdout);
    sleep(4); /* 给客户端布防留足时间 */
    printf("GO\n"); fflush(stdout);
    if (!strcmp(m, "ls")) {
        pthread_barrier_init(&bar, 0, 2);
        pthread_t a, b;
        pthread_create(&a, 0, thr_ls, (void*)1);
        pthread_create(&b, 0, thr_ls, (void*)2);
        pthread_join(a, 0); pthread_join(b, 0);
    } else {
        pthread_t t[4];
        for (long i = 0; i < 4; i++) pthread_create(&t[i], 0, thr_free, (void*)i);
        for (int i = 0; i < 4; i++) pthread_join(t[i], 0);
    }
    printf("ALLDONE\n"); fflush(stdout);
    sleep(20);
    return 0;
}