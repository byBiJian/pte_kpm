/* 机制实证: 调用方把 demo_add 的返回值当"状态码"；
 * 若命中把 X0 改成 0x1234，返回值 = 0x1234+2 = 4662，
 * 调用方检测到 4662 后认为"任务完成"，提前终止循环。
 * 预期: 不修改 -> 150 次调用; -r X0=0x1234 -> 第 1 次就终止（150 -> 1）。
 * 这证明"修改寄存器 -> 调用方逻辑改变 -> 调用次数变少"是真实可发生的机制。 */
#include <stdio.h>
#include <unistd.h>
extern int demo_add(int a, int b);
int main(void) {
    int calls = 0, magic = 0, first = -1;
    printf("mode=magic target=150\n"); fflush(stdout);
    sleep(4);
    printf("GO\n"); fflush(stdout);
    for (int i = 0; i < 150; i++) {
        int r = demo_add(1, 2);
        if (i == 0) first = r;
        calls++;
        if (r == 4662) { magic = 1; break; }
        usleep(80000);
    }
    printf("first_r=%d calls_made=%d magic=%d\n", first, calls, magic); fflush(stdout);
    sleep(8);
    return 0;
}