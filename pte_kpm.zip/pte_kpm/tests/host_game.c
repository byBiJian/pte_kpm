/* 游戏节奏仿真: 5 线程 x 50 次随机间隔调用, 共 250 次, 约 10 秒
 * 启动后 4 秒开始调用（给客户端布防留时间）
 * 用法: ./host_game */
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
extern int demo_add(int a, int b);

static void *worker(void *arg) {
    long id = (long)arg;
    unsigned r = (unsigned)(time(0) * 2654435761u) ^ (unsigned)(id * 998244353u + 7);
    long s = 0;
    if (!r) r = 0x9e3779b9u;
    r ^= r << 13; r ^= r >> 17; r ^= r << 5;
    usleep((useconds_t)(r % 150) * 1000); /* 随机错峰 0~150ms */
    for (int i = 0; i < 50; i++) {
        s += demo_add((int)id, i);
        r ^= r << 13; r ^= r >> 17; r ^= r << 5;
        usleep((useconds_t)(80 + r % 170) * 1000); /* 随机间隔 80~249ms */
    }
    printf("t%ld calls=50 s=%ld\n", id, s); fflush(stdout);
    return 0;
}
int main(void) {
    printf("mode=game5 threads=5 calls_each=50 total=250\n"); fflush(stdout);
    sleep(4);
    printf("GO\n"); fflush(stdout);
    pthread_t t[5];
    for (long i = 0; i < 5; i++) pthread_create(&t[i], 0, worker, (void *)(i + 1));
    for (int i = 0; i < 5; i++) pthread_join(t[i], 0);
    printf("ALLDONE total=250\n"); fflush(stdout);
    sleep(8);
    return 0;
}