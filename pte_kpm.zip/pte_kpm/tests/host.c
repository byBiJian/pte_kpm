#include <stdio.h>
#include <unistd.h>

extern int demo_add(int a, int b);
extern int demo_mul(int a, int b);

int main(void)
{
    setvbuf(stdout, 0, _IOLBF, 0);
    for (;;) {
        printf("add=%d mul=%d\n", demo_add(1, 2), demo_mul(3, 4));
        usleep(200000);
    }
    return 0;
}
