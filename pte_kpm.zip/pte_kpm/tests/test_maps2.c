/* SPDX-License-Identifier: GPL-2.0-or-later */
/* kpm-maps-test v2: /proc maps 读取通道诊断（零 hook、只读、仅临时加载）
 * 参数：maps 路径（默认 /proc/1/maps）
 */
#include <compiler.h>
#include <kpmodule.h>
#include <kallsyms.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <common.h>
#include <kputils.h>

KPM_NAME("kpm-maps-test");
KPM_VERSION("0.2");
KPM_LICENSE("GPL v2");
KPM_AUTHOR("operit");
KPM_DESCRIPTION("proc maps read-channel diagnostic, no hooks, temp load only");

static struct file *(*fn_filp_open)(const char *filename, int flags, unsigned short mode);
static ssize_t (*fn_seq_read)(struct file *file, char *buf, size_t count, loff_t *pos);
static int (*fn_filp_close)(struct file *filp, void *id);
static unsigned long (*fn_vm_mmap)(struct file *file, unsigned long addr, unsigned long len,
                                   unsigned long prot, unsigned long flag, unsigned long offset);
static int (*fn_vm_munmap)(unsigned long start, unsigned long len);
static unsigned long (*fn_arch_cfu)(void *to, const void *from, unsigned long n);

static int m_bad(unsigned long p) { return p >= 0xfffffffffffff000UL; }

static long maps_test_init(const char *args, const char *event, void *__user reserved)
{
    (void)event; (void)reserved;
    fn_filp_open = (void *)kallsyms_lookup_name("filp_open");
    fn_seq_read = (void *)kallsyms_lookup_name("seq_read");
    fn_filp_close = (void *)kallsyms_lookup_name("filp_close");
    fn_vm_mmap = (void *)kallsyms_lookup_name("vm_mmap");
    fn_vm_munmap = (void *)kallsyms_lookup_name("vm_munmap");
    fn_arch_cfu = (void *)kallsyms_lookup_name("__arch_copy_from_user");
    pr_info("[maps_test] syms %lx %lx %lx %lx %lx %lx\n",
            (unsigned long)fn_filp_open, (unsigned long)fn_seq_read,
            (unsigned long)fn_filp_close, (unsigned long)fn_vm_mmap,
            (unsigned long)fn_vm_munmap, (unsigned long)fn_arch_cfu);
    if (!fn_filp_open || !fn_seq_read || !fn_filp_close)
        return 0;

    const char *path = (args && args[0]) ? args : "/proc/1/maps";
    char kbuf[520];
    struct file *f;
    loff_t pos;
    ssize_t r;

    /* A: 内核缓冲直读 */
    f = fn_filp_open(path, 0, 0);
    pr_info("[maps_test] Aopen %lx\n", (unsigned long)f);
    if (!f || m_bad((unsigned long)f)) return 0;
    pos = 0;
    r = fn_seq_read(f, kbuf, sizeof(kbuf) - 1, &pos);
    pr_info("[maps_test] A ret=%ld pos=%lld\n", (long)r, (long long)pos);
    if (r > 0) {
        kbuf[r] = 0;
        pr_info("[maps_test] A ok head={%s}\n", kbuf);
        fn_filp_close(f, 0);
        return 0;
    }
    fn_filp_close(f, 0);

    /* B: vm_mmap 用户页 + seq_read + copy_from_user */
    if (!fn_vm_mmap || !fn_vm_munmap || !fn_arch_cfu) return 0;
    unsigned long uva = fn_vm_mmap(0, 0, 4096, 3, 0x22, 0);
    pr_info("[maps_test] B uva=%lx\n", uva);
    if (m_bad(uva)) return 0;
    f = fn_filp_open(path, 0, 0);
    if (!f || m_bad((unsigned long)f)) { fn_vm_munmap(uva, 4096); return 0; }
    pos = 0;
    r = fn_seq_read(f, (char *)uva, 511, &pos);
    pr_info("[maps_test] B ret=%ld pos=%lld\n", (long)r, (long long)pos);
    if (r > 0) {
        unsigned long left = fn_arch_cfu(kbuf, (const void *)uva, (unsigned long)r);
        size_t got = (size_t)r - (size_t)left;
        if (got < sizeof(kbuf)) {
            kbuf[got] = 0;
            pr_info("[maps_test] B ok head={%s}\n", kbuf);
        }
        pr_info("[maps_test] B left=%lu\n", left);
    }
    fn_filp_close(f, 0);
    fn_vm_munmap(uva, 4096);
    pr_info("[maps_test] done\n");
    return 0;
}

static long maps_test_exit(void *reserved)
{
    (void)reserved;
    pr_info("[maps_test] exit\n");
    return 0;
}

KPM_INIT(maps_test_init);
KPM_EXIT(maps_test_exit);
