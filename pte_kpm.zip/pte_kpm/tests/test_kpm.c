/* SPDX-License-Identifier: GPL-2.0-or-later
 * kpm-pte-test / pte_kpm 诊断隔离模块（仅临时加载，重启即消失）
 * 加载参数 = 模式：abort | step | prctl | none
 */
#include <compiler.h>
#include <kpmodule.h>
#include <hook.h>
#include <syscall.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <common.h>
#include <kputils.h>
#include <uapi/asm-generic/unistd.h>

KPM_NAME("kpm-pte-test");
KPM_VERSION("0.1.0");
KPM_LICENSE("GPL v2");
KPM_AUTHOR("operit");
KPM_DESCRIPTION("isolated hook test for pte_kpm diagnostics (temp load only)");

#include <kallsyms.h>

#ifndef DBG_HOOK_ERROR
#define DBG_HOOK_ERROR 1
#endif

/* 与内核 struct step_hook 同布局: {list_head node; fn} */
struct test_step_hook { unsigned long node[2]; int (*fn)(struct pt_regs *regs, unsigned long esr); };
static struct test_step_hook g_step_hook;

static int g_abort = 0, g_step = 0, g_prctl = 0;
static void (*fn_unreg_step)(struct test_step_hook *hook);
static void *g_dbg_lock;
static void (*fn_raw_lock)(void *);
static void (*fn_raw_unlock)(void *);

static struct file *(*fn_filp_open)(const char *filename, int flags, unsigned short mode);
static ssize_t (*fn_kernel_write)(struct file *file, const void *buf, size_t count, loff_t *pos);
static int (*fn_filp_close)(struct file *filp, void *id);

static void tlog(const char *s)
{
    if (!fn_filp_open || !fn_kernel_write || !fn_filp_close) return;
    struct file *f = fn_filp_open("/data/local/tmp/test_kpm.log", 01 | 0100 | 02000, 0644);
    if (!f || (unsigned long)f >= 0xfffffffffffff000UL) { pr_err("test_kpm: open log fail\n"); return; }
    loff_t pos = 0;
    fn_kernel_write(f, s, strlen(s), &pos);
    fn_filp_close(f, 0);
}

static void t_abort_before(hook_fargs3_t *f, void *u) { (void)f; (void)u; }
static void t_abort_after(hook_fargs3_t *f, void *u) { (void)f; (void)u; }
static int t_step_fn(struct pt_regs *r, unsigned long e) { (void)r; (void)e; return DBG_HOOK_ERROR; }
static void t_prctl_before(hook_fargs8_t *f, void *u) { (void)f; (void)u; }

static long pte_test_init(const char *args, const char *event, void *__user reserved)
{
    (void)reserved;
    const char *mode = (args && args[0]) ? args : "none";
    pr_info("test_kpm: init event=%s mode=%s\n", event, mode);

    fn_filp_open = (void *)kallsyms_lookup_name("filp_open");
    fn_kernel_write = (void *)kallsyms_lookup_name("kernel_write");
    fn_filp_close = (void *)kallsyms_lookup_name("filp_close");
    fn_unreg_step = (void *)kallsyms_lookup_name("unregister_user_step_hook");
    g_dbg_lock = (void *)kallsyms_lookup_name("debug_hook_lock");
    fn_raw_lock = (void *)kallsyms_lookup_name("_raw_spin_lock");
    fn_raw_unlock = (void *)kallsyms_lookup_name("_raw_spin_unlock");

    tlog("test_kpm init mode="); tlog(mode); tlog("\n");

    if (!strcmp(mode, "abort")) {
        void *fp = (void *)kallsyms_lookup_name("do_mem_abort");
        pr_info("test_kpm: do_mem_abort=%lx\n", (unsigned long)fp);
        hook_err_t e = hook_wrap3(fp, t_abort_before, t_abort_after, 0);
        pr_info("test_kpm: hook do_mem_abort rc=%d\n", e);
        g_abort = (e == HOOK_NO_ERR);
    } else if (!strcmp(mode, "step")) {
        void *reg = (void *)kallsyms_lookup_name("register_user_step_hook");
        pr_info("test_kpm: register_user_step_hook=%lx\n", (unsigned long)reg);
        if (reg) { g_step_hook.fn = t_step_fn; ((void (*)(struct test_step_hook *))reg)(&g_step_hook); g_step = 1; }
    } else if (!strcmp(mode, "prctl")) {
        hook_err_t e = fp_hook_syscalln(__NR_prctl, 5, t_prctl_before, 0, 0);
        pr_info("test_kpm: fp_hook prctl rc=%d\n", e);
        g_prctl = (e == HOOK_NO_ERR);
    } else {
        pr_info("test_kpm: control (no hooks)\n");
    }
    tlog("test_kpm init done\n");
    return 0;
}

static void safe_step_unlink(void)
{
    if (!g_step) return;
    unsigned long *lh = g_step_hook.node;
    unsigned long next = lh[0], prev = lh[1];
    if (next < 0xffff000000000000ULL || prev < 0xffff000000000000ULL) {
        tlog("step unlink skip bad ptr\n");
        return;
    }
    if (g_dbg_lock && fn_raw_lock && fn_raw_unlock) fn_raw_lock(g_dbg_lock);
    *(unsigned long *)(next + 8) = prev;
    *(unsigned long *)(prev + 0) = next;
    lh[0] = (unsigned long)&lh[0];
    lh[1] = (unsigned long)&lh[0];
    if (g_dbg_lock && fn_raw_lock && fn_raw_unlock) fn_raw_unlock(g_dbg_lock);
    g_step = 0;
}

static long pte_test_exit(void *reserved)
{
    (void)reserved;
    if (g_abort) hook_unwrap((void *)kallsyms_lookup_name("do_mem_abort"), t_abort_before, t_abort_after);
    if (g_prctl) fp_unhook_syscalln(__NR_prctl, t_prctl_before, 0);
    if (g_step) { tlog("step unlink start\n"); safe_step_unlink(); tlog("step unlink done\n"); }
    tlog("test_kpm exit\n");
    return 0;
}

KPM_INIT(pte_test_init);
KPM_EXIT(pte_test_exit);