/* SPDX-License-Identifier: GPL-2.0-or-later */
/* kpm-maps-test: /proc/pid/maps 读取诊断（零 hook、只读，仅临时加载）
 * 加载参数：maps 文件路径（如 /proc/1234/maps），无参数则默认 /proc/1/maps
 */
#include <compiler.h>
#include <kpmodule.h>
#include <kallsyms.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <common.h>
#include <kputils.h>

KPM_NAME("kpm-maps-test");
KPM_VERSION("0.1");
KPM_LICENSE("GPL v2");
KPM_AUTHOR("operit");
KPM_DESCRIPTION("read /proc/pid/maps diagnostic, no hooks, temp load only");

static struct file *(*fn_filp_open)(const char *filename, int flags, unsigned short mode);
static ssize_t (*fn_kernel_read)(struct file *file, void *buf, size_t count, loff_t *pos);
static int (*fn_filp_close)(struct file *filp, void *id);

static long maps_test_init(const char *args, const char *event, void *__user reserved)
{
    (void)event; (void)reserved;
    fn_filp_open = (void *)kallsyms_lookup_name("filp_open");
    fn_kernel_read = (void *)kallsyms_lookup_name("kernel_read");
    fn_filp_close = (void *)kallsyms_lookup_name("filp_close");
    pr_info("[maps_test] init args=%s syms=%lx/%lx/%lx\n",
            args ? args : "()", (unsigned long)fn_filp_open,
            (unsigned long)fn_kernel_read, (unsigned long)fn_filp_close);
    if (!fn_filp_open || !fn_kernel_read || !fn_filp_close) return 0;

    const char *path = (args && args[0]) ? args : "/proc/1/maps";
    struct file *f = fn_filp_open(path, 0, 0);
    pr_info("[maps_test] open [%s] -> %lx\n", path, (unsigned long)f);
    if (!f || (unsigned long)f >= 0xfffffffffffff000UL) return 0;

    char buf[300];
    loff_t pos = 0;
    ssize_t r1 = fn_kernel_read(f, buf, sizeof(buf) - 1, &pos);
    pr_info("[maps_test] read1 ret=%ld pos=%lld\n", (long)r1, (long long)pos);
    if (r1 > 0) {
        buf[r1] = 0;
        pr_info("[maps_test] head={%s}\n", buf);
    }
    ssize_t r2 = fn_kernel_read(f, buf, sizeof(buf) - 1, &pos);
    pr_info("[maps_test] read2 ret=%ld pos=%lld\n", (long)r2, (long long)pos);
    fn_filp_close(f, 0);
    pr_info("[maps_test] done\n");
    return 0;
}

static long maps_test_exit(void *reserved)
{
    (void)reserved;
    pr_info("[maps_test] exit\n");
    return 0;
}

KPM_INIT(maps_test_init);
KPM_EXIT(maps_test_exit);
