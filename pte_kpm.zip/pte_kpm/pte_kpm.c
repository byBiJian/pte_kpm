/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * pte_kpm.c - ARM64 PTE 断点 KPM 主实现
 * 仅用于网络安全研究，测试无 bug 后将开源到 GitHub。
 *
 * 核心流程：
 *  1. init 解析 6 参数（包名/so名/偏移/是否改寄存器/寄存器名/值）
 *  2. 定位目标进程（遍历 task 链表，匹配 cmdline 包名，过滤子进程）
 *  3. 解析目标 so 基址（读 /proc/pid/maps，匹配 so 名 + pgoff==0）
 *  4. 计算目标地址 = 基址 + 偏移，修改 PTE 的 UXN 位（权限异常断点）
 *  5. hook do_mem_abort：命中 IABT_LOW + IFSC_PERM + 地址匹配 -> 改寄存器(可选) ->
 *     恢复 PTE + TLB flush -> 设单步 -> skip_origin=1（吞 SIGSEGV）
 *  6. 单步异常（EC=0x32）-> single_step_handler -> call_step_hook -> 我们的
 *     user_step_hook 回调：页内继续单步跟随，离开断点页则停单步 + 重新布防 UXN。
 *     返回 DBG_HOOK_HANDLED 使内核不发 SIGTRAP（目标进程完全无感）
 *  7. exit：卸 hook、恢复 PTE、清理
 *
 * 明确定位：全程无 ptrace、无影子页、无 ghost 页、无代码段修改、无注入。
 */

#include "pte_kpm.h"
#include <asm/ptrace.h>
#include <asm/processor.h>
#include <linux/fs.h>
#include <syscall.h>
#include <linux/uaccess.h>
#include <kputils.h>

/* ======================= 符号查找 ======================= */
typedef int (*do_mem_abort_fn)(unsigned long far, unsigned long esr, void *regs);

static do_mem_abort_fn fn_do_mem_abort;
static struct task_struct *(*fn_find_task_by_vpid)(pid_t nr);
static get_task_mm_t fn_get_task_mm;
static mmput_t fn_mmput;
static int (*fn_get_cmdline)(struct task_struct *task, char *buffer, int buflen);
/* 内核原生 pid/tgid 查询（KPatch-Next 的 task_struct 偏移表里 pid/tgid/tasks 恒为 -1，
 * 绝不能拿这些偏移去解引用，否则空指针 -> 内核 panic） */
static pid_t (*fn_task_pid_nr_ns)(struct task_struct *task, int type, void *ns);
/* 单步 hook（5.15 内核标准扩展点，用户态单步异常时被 call_step_hook 调用） */
struct step_hook {
    struct list_head node;
    int (*fn)(struct pt_regs *regs, unsigned long esr);
};
static struct step_hook g_step_hook;

static void (*fn_register_user_step_hook)(struct step_hook *hook);
static void (*fn_user_enable_single_step)(struct task_struct *task);
static void (*fn_user_disable_single_step)(struct task_struct *task);
/* 安全摘链支持：官方 unregister_user_step_hook 内部 synchronize_rcu() 会与
 * KernelPatch/KPatch-Next 卸载路径持有的 rcu_read_lock 自死锁（已实测）。
 * 仿 wxshadow：自持内核 debug_hook_lock 手动 list_del_rcu，绝不调 synchronize_rcu。 */
static void *g_dbg_hook_lock;
static void (*fn_raw_spin_lock)(void *);
static void (*fn_raw_spin_unlock)(void *);

static int g_hook_installed = 0;
static int g_hook_step_installed = 0;
static int g_hook_prctl_installed = 0;
static int g_disarming = 0; /* 撤防收尾中：单步线程自然排空，不再重布防 */
static uint64_t g_linear_voff = 0; /* linear map offset（phys + off = virt） */

/* ======================= 状态 ======================= */
static bp_state_t g_bp;

/* 处于单步中的线程 tid 集合（支持多线程并发命中） */
#define MAX_STEP 8
static pid_t g_step_tids[MAX_STEP];
static uint8_t g_step_ext[MAX_STEP]; /* 1=该 tid 同时被外部（ptrace）单步 */

/* 原子占槽：多核并发命中时避免两线程写同一空槽 */
static int step_tid_add(pid_t t)
{
    for (int i = 0; i < MAX_STEP; i++) {
        if (g_step_tids[i] == t) return 0;
        if (g_step_tids[i] == 0) {
            pid_t expect = 0;
            if (__atomic_compare_exchange_n(&g_step_tids[i], &expect, t, 0,
                                            __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
                g_step_ext[i] = 0; /* 复用槽位必须清残留的外部单步标记 */
                return 0;
            }
            if (g_step_tids[i] == t) return 0;
        }
    }
    return -1;
}

static int step_tid_has(pid_t t)
{
    for (int i = 0; i < MAX_STEP; i++)
        if (__atomic_load_n(&g_step_tids[i], __ATOMIC_ACQUIRE) == t) return 1;
    return 0;
}

static void step_tid_del(pid_t t)
{
    for (int i = 0; i < MAX_STEP; i++)
        if (__atomic_load_n(&g_step_tids[i], __ATOMIC_ACQUIRE) == t) {
            __atomic_store_n(&g_step_tids[i], 0, __ATOMIC_RELEASE);
            g_step_ext[i] = 0;
            return;
        }
}

/* 外部单步标记（目标自己 ptrace 单步自身时借用其单步） */
static void step_ext_set(pid_t t, int ext)
{
    for (int i = 0; i < MAX_STEP; i++)
        if (__atomic_load_n(&g_step_tids[i], __ATOMIC_ACQUIRE) == t) {
            g_step_ext[i] = (uint8_t)ext;
            return;
        }
}

static int step_ext_get(pid_t t)
{
    for (int i = 0; i < MAX_STEP; i++)
        if (__atomic_load_n(&g_step_tids[i], __ATOMIC_ACQUIRE) == t)
            return g_step_ext[i];
    return 0;
}

/* 当前处于单步的线程数（用于“集合空才重布防”判定） */
static int step_tid_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_STEP; i++)
        if (__atomic_load_n(&g_step_tids[i], __ATOMIC_ACQUIRE)) n++;
    return n;
}

/* ======================= 日志 ======================= */
/* dmesg 输出（init/exit 等关键事件用） */
#define LOG(fmt, ...) pr_info("[pte_kpm] " fmt "\n", ##__VA_ARGS__)

/* log.log 落盘：hook 在异常上下文不能做文件 IO，
 * 故先写内存环形缓冲，在 init/exit/ctl0（进程上下文）刷盘 */
#define LOG_PATH "/data/local/tmp/pte_kpm.log"
#define LOG_SLOTS 256 /* 环形缓冲：仅保留最近若干条；运行中可用 kpatch kpm ctl0 触发落盘 */
#define LOG_LINE 160
static char g_log[LOG_SLOTS][LOG_LINE];
static int g_log_cnt = 0;
static unsigned long g_log_seq = 0;   /* 事件序号（判断是否发生过覆盖） */
static unsigned long g_hit_total = 0; /* 累计命中次数（客户端 -s 查询） */

/* 诊断统计：被拦页面的"页内执行分布"（64 桶 × 64 字节/桶）
 * 排查"函数明明执行却没命中"时，看页面里到底哪些区域跑过 */
static unsigned long g_fault_cnt = 0, g_sin_cnt = 0;
static unsigned int g_far_hist[64], g_sin_hist[64];

static void diag_reset(void)
{
    g_fault_cnt = 0;
    g_sin_cnt = 0;
    for (int i = 0; i < 64; i++) { g_far_hist[i] = 0; g_sin_hist[i] = 0; }
}

static void log_event(const char *fmt, ...)
{
    if (g_log_cnt >= LOG_SLOTS) {
        memmove(g_log[0], g_log[1], (size_t)LOG_LINE * (LOG_SLOTS - 1));
        g_log_cnt = LOG_SLOTS - 1;
    }
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    char tmp_line[LOG_LINE];
    vsnprintf(tmp_line, sizeof(tmp_line), fmt, ap);
    __builtin_va_end(ap);
    snprintf(g_log[g_log_cnt], LOG_LINE, "[%lu] %s", g_log_seq++, tmp_line);
    g_log_cnt++;
}

static struct file *(*fn_filp_open)(const char *filename, int flags, umode_t mode);
static ssize_t (*fn_kernel_read)(struct file *file, void *buf, size_t count, loff_t *pos);
static ssize_t (*fn_kernel_write)(struct file *file, const void *buf, size_t count, loff_t *pos);
static int (*fn_filp_close)(struct file *filp, void *id);

static void diag_dump(void)
{
    if (!g_fault_cnt && !g_sin_cnt) return;
    char buf[LOG_LINE];
    log_event("DIAG pg=%lx bp=%lx tgid=%d faults=%lu sins=%lu hits=%lu",
              (unsigned long)g_bp.bp_page, (unsigned long)g_bp.bp_addr,
              g_bp.tgt_tgid, g_fault_cnt, g_sin_cnt, g_hit_total);
    for (int r = 0; r < 8; r++) {
        int n = snprintf(buf, sizeof(buf), "fh%02d:", r * 8);
        for (int i = 0; i < 8; i++)
            n += snprintf(buf + n, sizeof(buf) - n, " %u", g_far_hist[r * 8 + i]);
        log_event("%s", buf);
    }
    for (int r = 0; r < 8; r++) {
        int n = snprintf(buf, sizeof(buf), "sh%02d:", r * 8);
        for (int i = 0; i < 8; i++)
            n += snprintf(buf + n, sizeof(buf) - n, " %u", g_sin_hist[r * 8 + i]);
        log_event("%s", buf);
    }
}

static void log_flush(void)
{
    diag_dump();
    if (g_log_cnt <= 0) return;
    struct file *f = fn_filp_open(LOG_PATH, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (!f || (unsigned long)f >= 0xfffffffffffff000UL) {
        LOG("open log fail");
        g_log_cnt = 0;
        return;
    }
    loff_t pos = 0;
    for (int i = 0; i < g_log_cnt; i++) {
        size_t n = strlen(g_log[i]);
        if (n >= LOG_LINE - 1) n = LOG_LINE - 2;
        g_log[i][n] = '\n';
        fn_kernel_write(f, g_log[i], n + 1, &pos);
    }
    fn_filp_close(f, NULL);
    g_log_cnt = 0;
}

/* ======================= 内核符号解析 ======================= */
static void *lookup(const char *name)
{
    void *addr = (void *)kallsyms_lookup_name(name);
    if (!addr)
        LOG("sym miss: %s", name);
    return addr;
}

/* linear map 偏移：phys + off = virt = PAGE_OFFSET - memstart_addr */
static int detect_linear_voff(void)
{
    uint64_t tcr_el1;
    asm volatile("mrs %0, tcr_el1" : "=r"(tcr_el1));
    uint64_t t1sz = (tcr_el1 >> 16) & 0x3f;
    uint64_t va_bits = 64 - t1sz;
    uint64_t page_offset = (~0UL) << va_bits;

    s64 *msa = (s64 *)lookup("memstart_addr");
    if (!msa) return -1;
    g_linear_voff = page_offset - (uint64_t)(*msa);
    LOG("va_bits=%lu linear_voff=0x%lx", va_bits, g_linear_voff);
    return 0;
}

static int resolve_symbols(void)
{
    fn_do_mem_abort = (do_mem_abort_fn)lookup("do_mem_abort");
    fn_find_task_by_vpid = (void *)lookup("find_task_by_vpid");
    fn_register_user_step_hook = (void *)lookup("register_user_step_hook");
    g_dbg_hook_lock = (void *)lookup("debug_hook_lock");
    fn_raw_spin_lock = (void *)lookup("_raw_spin_lock");
    fn_raw_spin_unlock = (void *)lookup("_raw_spin_unlock");
    fn_user_enable_single_step = (void *)lookup("user_enable_single_step");
    fn_user_disable_single_step = (void *)lookup("user_disable_single_step");
    fn_get_task_mm = (get_task_mm_t)lookup("get_task_mm");
    fn_mmput = (mmput_t)lookup("mmput");
    fn_get_cmdline = (void *)lookup("get_cmdline");
    fn_task_pid_nr_ns = (void *)lookup("__task_pid_nr_ns");
    fn_filp_open = (void *)lookup("filp_open");
    fn_kernel_read = (void *)lookup("kernel_read");
    fn_kernel_write = (void *)lookup("kernel_write");
    fn_filp_close = (void *)lookup("filp_close");

    if (!fn_do_mem_abort || !fn_find_task_by_vpid || !fn_register_user_step_hook ||
        !fn_user_enable_single_step || !fn_user_disable_single_step ||
        !fn_get_task_mm || !fn_mmput || !fn_get_cmdline || !fn_task_pid_nr_ns ||
        !fn_filp_open || !fn_kernel_read || !fn_kernel_write || !fn_filp_close) {
        LOG("symbols missing");
        return -1;
    }
    return 0;
}

/* ======================= 进程定位（匹配 cmdline 包名，主进程） ======================= */
/* KPatch-Next 的 task_struct 偏移表里 pid/tgid/tasks 恒为 -1（平台不填），
 * 因此不再遍历内核 task 链表、不再自解引用这些偏移，全部走内核原生函数。 */
#define PIDTYPE_PID_ENUM 0
#define PIDTYPE_TGID_ENUM 1

static pid_t task_tid(struct task_struct *t)
{
    return (t && fn_task_pid_nr_ns) ? fn_task_pid_nr_ns(t, PIDTYPE_PID_ENUM, NULL) : -1;
}

static pid_t task_tgid(struct task_struct *t)
{
    return (t && fn_task_pid_nr_ns) ? fn_task_pid_nr_ns(t, PIDTYPE_TGID_ENUM, NULL) : -1;
}

/* 按 pid 号探测进程（find_task_by_vpid + 原生 tgid 查询 + get_cmdline 匹配） */
static pid_t find_main_process(const char *pkg)
{
    char cmdline[512];
    size_t plen = strlen(pkg);

    for (pid_t pid = 1; pid < 65536; pid++) {
        struct task_struct *t = fn_find_task_by_vpid(pid);
        if (!t) continue;
        if (task_tgid(t) != pid) continue; /* 只认主进程（线程 tid != tgid） */
        memset(cmdline, 0, sizeof(cmdline));
        if (fn_get_cmdline(t, cmdline, sizeof(cmdline) - 1) <= 0)
            continue;
        const char *name = cmdline;
        if (!strncasecmp(name, pkg, plen) &&
            (name[plen] == '\0' || name[plen] == ' ' || name[plen] == '\n')) {
            return pid;
        }
    }
    return -1;
}

/* 十六进制解析（手动实现，不依赖 sscanf，KPM 环境更稳） */
static unsigned long parse_hex(const char **ps)
{
    const char *s = *ps;
    unsigned long v = 0;
    int nd = 0;
    for (;;) {
        char c = *s;
        if (c >= '0' && c <= '9') v = (v << 4) | (unsigned long)(c - '0');
        else if (c >= 'a' && c <= 'f') v = (v << 4) | (unsigned long)(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') v = (v << 4) | (unsigned long)(c - 'A' + 10);
        else break;
        s++; nd++;
    }
    *ps = s;
    return nd ? v : 0;
}

/* 解析单行 maps：匹配 so 名 + offset==0，取最小 start（手动解析） */
static void parse_maps_line(char *line, const char *so_name, unsigned long *best)
{
    char needle[MAX_SO_NAME + 2];
    snprintf(needle, sizeof(needle), "/%s", so_name);
    char *pathp = strstr(line, needle);
    if (!pathp) return;
    char nxt = pathp[strlen(needle)];
    if (nxt != '\0' && nxt != '\n' && nxt != '\r' && nxt != ' ' && nxt != '\t')
        return;

    const char *p = line;
    const char *p0 = p;
    unsigned long start = parse_hex(&p);
    if (p == p0 || *p != '-') return;
    p++;
    p0 = p;
    (void)parse_hex(&p); /* end */
    if (p == p0) return;
    /* 跳过 perms 字段 */
    while (*p == ' ') p++;
    while (*p && *p != ' ') p++;
    /* 跳到 offset 字段 */
    while (*p == ' ') p++;
    p0 = p;
    unsigned long off = parse_hex(&p);
    if (p == p0 || off != 0) return;
    if (!*best || start < *best) *best = start;
}

/* ======================= so 基址解析（读 /proc/pid/maps） ======================= */
static int resolve_so_base(pid_t pid, const char *so_name, unsigned long *base_out)
{
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);

    struct file *filp = fn_filp_open(path, 0 /* O_RDONLY */, 0);
    if (!filp || (unsigned long)filp >= 0xfffffffffffff000UL) {
        LOG("open %s fail", path);
        return -1;
    }

    char buf[2048];
    loff_t pos = 0;
    unsigned long best = 0;
    size_t carry = 0;
    size_t total_read = 0;

    for (;;) {
        ssize_t ret = fn_kernel_read(filp, buf + carry, sizeof(buf) - carry - 1, &pos);
        if (ret < 0) { LOG("maps read err=%ld", (long)ret); break; }
        if (ret == 0) break;
        total_read += (size_t)ret;
        size_t total = (size_t)ret + carry;
        buf[total] = '\0';

        char *line = buf;
        char *nl;
        while ((nl = strchr(line, '\n')) != NULL) {
            *nl = '\0';
            parse_maps_line(line, so_name, &best);
            line = nl + 1;
        }
        /* 保留尾部不完整行到下一块开头 */
        carry = strlen(line);
        if (carry >= sizeof(buf) / 2) carry = 0;
        memmove(buf, line, carry);
        buf[carry] = '\0';
    }
    fn_filp_close(filp, NULL);

    if (!best) {
        LOG("so not found: %s (read %lu bytes)", so_name, (unsigned long)total_read);
        return -1;
    }
    *base_out = best;
    LOG("so %s base=0x%lx", so_name, best);
    return 0;
}

/* ======================= PTE 操作 ======================= */
static int pte_set_uxn(unsigned long addr)
{
    /* mm->pgd 本身就是内核线性映射的 VA（page-table 指针都是 linear-map VA），
     * 直接传给 pgtable_entry；切勿再加 g_linear_voff（那是 phys->virt 转换，
     * 加了会得到非法地址，此前已致内核 paging fault） */
    uint64_t pgd_va = *(uint64_t *)((uintptr_t)g_bp.mm + mm_struct_offset.pgd_offset);
    uint64_t *pte = pgtable_entry(pgd_va, addr);
    if (!pte) return -1;
    g_bp.pte_ptr = pte;
    uint64_t cur = *pte;
    if (!(cur & PTE_VALID)) {
        LOG("pte invalid");
        return -1;
    }
    g_bp.orig_pte = cur;
    /* 幂等：已置位则直接返回，省一次 TLB 刷 */
    if (cur & PTE_UXN) { g_bp.armed = 1; return 0; }
    /* 原子置位：只动 UXN，避免覆盖系统对同页的并发修改（NUMA/ksm/reclaim） */
    uint64_t old = cur;
    while (!__atomic_compare_exchange_n(pte, &old, old | PTE_UXN, 0,
                                        __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
        if (old & PTE_UXN) break; /* 已被并发置位 */
    }
    flush_tlb_all();
    g_bp.armed = 1;
    return 0;
}

static int pte_clear_uxn(void)
{
    if (!g_bp.pte_ptr) return 0;
    /* 以 PTE 实际状态为准（多线程下 armed 标志可能滞后）：
     * 若 UXN 已不在，直接返回，避免“标志=0 但 PTE 仍锁”时永不解锁。 */
    uint64_t old = __atomic_load_n(g_bp.pte_ptr, __ATOMIC_ACQUIRE);
    if (!(old & PTE_UXN)) { g_bp.armed = 0; return 0; }
    while (!__atomic_compare_exchange_n(g_bp.pte_ptr, &old, old & ~PTE_UXN, 0,
                                        __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
        if (!(old & PTE_UXN)) break;
    }
    flush_tlb_all();
    g_bp.armed = 0;
    return 0;
}

/* ======================= 单步 ======================= */
/* 按参数修改目标寄存器（X0..X8 / W0..W8） */
static void apply_reg_modify(struct pt_regs *regs)
{
    if (!g_bp.modify_reg) return;
    char rn0 = g_bp.reg_name[0];
    int idx = g_bp.reg_name[1] - '0';
    if ((rn0 == 'X' || rn0 == 'x') && idx >= 0 && idx <= 8) {
        regs->regs[idx] = g_bp.reg_value;
        log_event("mod X%d=0x%lx", idx, regs->regs[idx]);
    } else if ((rn0 == 'W' || rn0 == 'w') && idx >= 0 && idx <= 8) {
        regs->regs[idx] = (uint64_t)(uint32_t)g_bp.reg_value;
        log_event("mod W%d=0x%x", idx, (uint32_t)g_bp.reg_value);
    }
}

/* 用户态单步异常回调，注册到 user_step_hook（EC=0x32 时被 call_step_hook 调用）。
 * 返回 DBG_HOOK_HANDLED(0) 表示已处理，内核不会再发 SIGTRAP。 */
static int step_hook_fn(struct pt_regs *regs, unsigned long esr)
{
    if (!current) return DBG_HOOK_ERROR;

    /* 只处理目标线程组（内核原生 tgid 查询，不用 KP 偏移表） */
    if (task_tgid(current) != g_bp.tgt_tgid) return DBG_HOOK_ERROR;

    /* 外部单步借用：该陷阱属于目标自身的 ptrace tracer，必须归还，
     * 否则 tracer 收不到停止事件（行为可被目标检测）。此分支先于
     * 撤防判定，避免撤防收尾误清它的 TIF。 */
    {
        int tid_e = task_tid(current);
        if (step_ext_get(tid_e)) {
            step_tid_del(tid_e); /* 清登记 + ext */
            /* 无条件重布防：断点必须持续有效。若 pc 仍在断点页内，
             * 外部单步步进时会被我们的 IABT 拦（我们照常给寄存器放行、
             * 不吞它的停止事件），只是开销加倍，不影响其正确性。 */
            if (g_bp.active && !g_disarming)
                pte_set_uxn(g_bp.bp_addr);
            log_event("STEP ext-return tid=%d", tid_e);
            return DBG_HOOK_ERROR; /* 归还给外部 tracer（内核发 SIGTRAP） */
        }
    }

    /* 撤防（active=0）后残留的单步异常兜底：bp_disarm/exit 清理期间，
     * 目标线程可能已进入单步异常但 TIF 刚被清掉。此时若直接返回
     * DBG_HOOK_ERROR，内核会发 SIGTRAP（假信号）。
     * 仅当该 tid 仍在我们的登记表里（确实是我们留下的单步）才吞。 */
    if (!g_bp.active || !g_bp.mm || g_disarming) {
        struct thread_info *ti0 = get_task_thread_info(current);
        int tid0 = task_tid(current);
        if (ti0 && step_tid_has(tid0)) {
            /* 撤防收尾：这是我们留下的单步（在登记表里）。
             * 不论 TIF 是否已被兜底清理，都吞掉并停步。
             * 非登记项一律放行（如目标自己的 ptrace 单步）。 */
            fn_user_disable_single_step(current);
            step_tid_del(tid0);
            regs->pstate &= ~DBG_SPSR_SS;
            return DBG_HOOK_HANDLED;
        }
        return DBG_HOOK_ERROR;
    }

    /* 当前线程必须处于单步中（TIF_SINGLESTEP 仅在命中时由我们设置，per-thread 精确判定） */
    struct thread_info *ti = get_task_thread_info(current);
    if (!(ti->flags & _TIF_SINGLESTEP)) return DBG_HOOK_ERROR;
    int cur_tid = task_tid(current);

    /* 关键：只处理我们自己登记的 tid。
     * 目标进程可能自己也用 ptrace 单步自身（反调试/自检），那同样会置
     * TIF_SINGLESTEP 并触发 EC=0x32。若我们不区分，会误吞它的单步异常，
     * 导致它的 tracer 收不到停止事件（行为可被目标检测）。
     * 我们只在命中时登记 tid，所以不在登记表里的一律放行。 */
    if (!step_tid_has(cur_tid)) return DBG_HOOK_ERROR;

    unsigned long next_pc = regs->pc;

    if ((next_pc & PAGE_MASK_4K) == (g_bp.bp_page & PAGE_MASK_4K)) {
        /* 下一条指令仍在断点页内：保持 TIF_SINGLESTEP 并重置 SPSR.SS。
         * 单步异常触发时硬件已清 PSTATE.SS，必须设回，否则返回用户态后
         * 单步不再触发（断点变一次性）。页内不记日志（性能优先）。 */
        /* 诊断：记录单步执行过的页内地址分布 */
        g_sin_cnt++;
        g_sin_hist[(next_pc >> 6) & 63]++;

        /* eager 重布防：立刻重新上锁，把其他线程的漏拦窗口从
         * "本线程整个页内停留期"压缩到"单条指令级"。
         * 本线程下一步取指会再触发 IABT（far≠bp_addr），由命中处理
         * 解锁放行——形成每指令一步的推进，功能不受影响。 */
        /*无条件尝试重锁：不用 armed门控（多线程下该标志可能滞后，导致永久解锁） */
 if (!g_disarming)
 pte_set_uxn(g_bp.bp_addr);
        regs->pstate |= DBG_SPSR_SS;
        return DBG_HOOK_HANDLED;
    }

    /* 离开断点页：停止单步 + 重新布防 UXN。
     * 关键：user_disable_single_step 只清 TIF，SPSR.SS 仍为 1，
     * 必须同时清 regs->pstate.SS，否则返回用户态后再次单步异常，
     * 而 TIF 已清导致我们不再处理 -> 内核发 SIGTRAP。 */
    log_event("STEP leave pid=%d pc=0x%lx", cur_tid, next_pc);
    step_tid_del(cur_tid);
    fn_user_disable_single_step(current);
    regs->pstate &= ~DBG_SPSR_SS;
    /* 仍有其他线程在单步时不要重布防（否则它们下次执行断点页指令
     * 会被 UXN 再拦一次，产生多余 HIT 与额外 TLB 刷）；
     * 撤防中（g_disarming）也绝不重布防。 */
    if (g_bp.active && !g_disarming)
        pte_set_uxn(g_bp.bp_addr);
    return DBG_HOOK_HANDLED;
}

/* ======================= do_mem_abort hook ======================= */
static void before_do_mem_abort(hook_fargs3_t *fargs, void *udata)
{
    if (!g_bp.active) return;

    unsigned long far = fargs->arg0;
    unsigned long esr = fargs->arg1;
    struct pt_regs *regs = (struct pt_regs *)fargs->arg2;

    /* 只处理用户态指令 abort + 权限错误（FSC 低2位为 level，需按 FSC_TYPE 掩码比较） */
    if (ESR_ELx_EC(esr) != ESR_ELx_EC_IABT_LOW) return;
    if ((esr & ESR_ELx_FSC_TYPE) != ESR_ELx_FSC_PERM) return;

    /* 必须命中断点页（PTE 是页级属性，页内任何地址都会 fault；
       页内非断点地址也要处理，否则内核发 SIGSEGV） */
    if ((far & PAGE_MASK_4K) != (g_bp.bp_page & PAGE_MASK_4K)) return;

    /* 目标进程判定：同线程组（tgid 匹配，兼容多线程 App）。
     * 线程共享同一 mm，不需要切换 mm（切换会丢引用计数） */
    if (!current) return;
    if (task_tgid(current) != g_bp.tgt_tgid) return;

    g_fault_cnt++;
    g_far_hist[(far >> 6) & 63]++;

    /* 只有精确命中断点地址才算“真命中”。
     * eager 重布防模式下，页内每条指令重放都会触发 IABT（far≠bp_addr），
     * 那些只是页面锁的重放，不记日志、不覆盖命中信息、不改寄存器。 */
    if (far == g_bp.bp_addr) {
        g_hit_total++;
        log_event("HIT pid=%d far=0x%lx esr=0x%lx pc=0x%lx lr=0x%lx",
                  task_tid(current), far, esr, regs->pc, regs->regs[30]);
        g_bp.hit_pc = regs->pc;
        g_bp.hit_lr = regs->regs[30];
        apply_reg_modify(regs);
    }

    /* 恢复 PTE（清 UXN），让原指令可执行 */
    pte_clear_uxn();

    /* 启用单步（TIF_SINGLESTEP，内核返回用户态时自动设 MDSCR.SS） */
    int hit_tid = task_tid(current);
    /* eager 模式下"页内重放"时该线程已在我们登记表里（TIF 也是我们设的），
     * 必须与"外部 ptrace 单步"区分，否则会误判 ext 归还 -> 假 SIGTRAP。 */
    int already_ours = step_tid_has(hit_tid);
    int step_slot_ok = (step_tid_add(hit_tid) == 0);
    if (!step_slot_ok) {
        /* 槽满（>MAX_STEP 个线程同时单步）：不能启用我们的单步，
         * 否则 step_hook 因"不在登记表"放行 -> 内核发假 SIGTRAP。
         * 本次已解锁 PTE，该线程降级为普通执行（本次穿越不拦，
         * 断点指令本身的寄存器修改已在上面完成）。 */
        log_event("STEP slot full tid=%d (degraded)", hit_tid);
    }
    g_bp.step_tid = hit_tid;
    /* 共存处理：若该线程已被外部 ptrace 单步（TIF 已置且不在我们登记表），
     * 它执行完本条指令会触发"外部期望的"单步事件；我们不能吞，标记 ext
     * 让 step_hook 放行，否则其 tracer 收不到停止事件（目标可检测到异常）。
     * 槽满（降级）时两件事都不做：不登记就别启用单步，否则假 SIGTRAP。 */
    if (step_slot_ok) {
        struct thread_info *hti = get_task_thread_info(current);
        if (!already_ours && hti && (hti->flags & _TIF_SINGLESTEP)) {
            step_ext_set(hit_tid, 1);
            log_event("STEP ext-borrow tid=%d", hit_tid);
        } else {
            step_ext_set(hit_tid, 0);
            fn_user_enable_single_step(current);
        }
    }
    /* 跳过原 do_mem_abort，防止发 SIGSEGV */
    fargs->skip_origin = 1;
}

static void after_do_mem_abort(hook_fargs3_t *fargs, void *udata)
{
    (void)fargs; (void)udata;
}

/* 安全摘除 step hook：不调用官方 unregister_user_step_hook（其内部
 * synchronize_rcu() 在 KP/KPN 卸载上下文 rcu_read_lock 中会自死锁，
 * 已实测：加载后卸载即全系统渐冻卡死）。改为自持 debug_hook_lock
 * 手动摘链并重置节点（与 mkpms/wxshadow 同款规避手法）。 */
static void safe_step_unlink(void)
{
    unsigned long *lh = (unsigned long *)&g_step_hook.node;
    unsigned long next = lh[0], prev = lh[1];
    if (next < 0xffff000000000000UL || prev < 0xffff000000000000UL) {
        LOG("step unlink: bad ptr, skip");
        return;
    }
    if (g_dbg_hook_lock && fn_raw_spin_lock && fn_raw_spin_unlock)
        fn_raw_spin_lock(g_dbg_hook_lock);
    else
        LOG("step unlink: no hook lock (unsafe mode)");
    *(unsigned long *)(next + 8) = prev; /* next->prev = prev */
    *(unsigned long *)(prev + 0) = next; /* prev->next = next */
    lh[0] = (unsigned long)&lh[0];
    lh[1] = (unsigned long)&lh[0];
    if (g_dbg_hook_lock && fn_raw_spin_lock && fn_raw_spin_unlock)
        fn_raw_spin_unlock(g_dbg_hook_lock);
    LOG("step unlink done");
}

/* ======================= 参数解析 ======================= */
static int parse_args(const char *args)
{
    char pkg[MAX_PKG_NAME];
    char so[MAX_SO_NAME];
    char off_str[32];
    char mode[8];
    char reg[8];
    char val_str[32];

    if (!args) {
        LOG("args null");
        return -1;
    }

    int n = sscanf(args, "%127s %127s %31s %7s %7s %31s",
                   pkg, so, off_str, mode, reg, val_str);
    if (n < 3) {
        LOG("args fmt err: %s", args);
        return -1;
    }
    if (n < 6 && (mode[0] == 'I' || mode[0] == 'i')) {
        LOG("mode=I but reg/val missing");
        return -1;
    }

    unsigned long long off = 0;
    if (!strncmp(off_str, "0x", 2) || !strncmp(off_str, "0X", 2))
        kstrtoull(off_str, 16, &off);
    else
        kstrtoull(off_str, 10, &off);

    pid_t pid = find_main_process(pkg);
    if (pid < 0) {
        LOG("proc not found: %s", pkg);
        return -1;
    }
    g_bp.pid = pid;

    struct task_struct *task = fn_find_task_by_vpid(pid);
    if (!task) {
        LOG("task not found");
        return -1;
    }
    g_bp.task = task;
    g_bp.tgt_tgid = task_tgid(task);

    struct mm_struct *mm = fn_get_task_mm(task);
    if (!mm) {
        LOG("get_task_mm fail");
        return -1;
    }
    g_bp.mm = mm;

    unsigned long base = 0;
    if (resolve_so_base(pid, so, &base) != 0) {
        fn_mmput(mm);
        /* 关键：必须清指针，否则 exit 会对同一 mm 二次 mmput（曾致内核 panic） */
        g_bp.mm = NULL;
        return -1;
    }

    g_bp.bp_addr = base + off;
    g_bp.bp_page = g_bp.bp_addr & PAGE_MASK_4K;
    LOG("target va=0x%lx (base=0x%lx off=0x%lx)", g_bp.bp_addr, base, off);

    if (mode[0] == 'I' || mode[0] == 'i') {
        g_bp.modify_reg = 1;
        strncpy(g_bp.reg_name, reg, sizeof(g_bp.reg_name) - 1);
        g_bp.reg_name[sizeof(g_bp.reg_name) - 1] = '\0';
        unsigned long long v = 0;
        kstrtoull(val_str, 0, &v);
        g_bp.reg_value = v;
        LOG("mode=I reg=%s val=0x%lx", g_bp.reg_name, g_bp.reg_value);
    } else {
        g_bp.modify_reg = 0;
    }

    return 0;
}

/* ======================= prctl 交互接口（用户态客户端） ======================= */
/* 客户端已解析好 pid 与绝对地址，内核只做布防/撤防 */

static int bp_arm(pid_t tgid, unsigned long addr, uint64_t pack, uint64_t val)
{
    if (g_bp.active) { LOG("prctl arm: already armed"); return -1; }

    /* 清理上一轮撤防遗留的登记项：只清“对应线程已不在单步”的；
     * 仍处于单步窗口的保留，交给 step_hook 兜底按表吞掉。
     * 同时重置撤防标记，否则新命中的单步会被误判为残留。 */
    for (int i = 0; i < MAX_STEP; i++) {
        if (!g_step_tids[i]) continue;
        struct task_struct *t = fn_find_task_by_vpid(g_step_tids[i]);
        int still = 0;
        if (t) {
            struct thread_info *ti = get_task_thread_info(t);
            if (ti && (ti->flags & _TIF_SINGLESTEP)) still = 1;
        }
        if (!still) { g_step_tids[i] = 0; g_step_ext[i] = 0; }
    }
    g_disarming = 0;

    struct task_struct *task = fn_find_task_by_vpid(tgid);
    if (!task) return -2;
    if (task_tgid(task) != tgid) return -2;

    struct mm_struct *mm = fn_get_task_mm(task);
    if (!mm) return -3;

    g_bp.pid = tgid;
    g_bp.task = task;
    g_bp.tgt_tgid = tgid;
    g_bp.mm = mm;
    g_bp.bp_addr = addr;
    g_bp.bp_page = addr & PAGE_MASK_4K;

    if (pack == REG_NONE_PACK) {
        g_bp.modify_reg = 0;
    } else {
        int idx = REG_PACK_IDX(pack);
        if (idx > 8) { fn_mmput(mm); g_bp.mm = NULL; return -5; }
        g_bp.modify_reg = 1;
        g_bp.reg_name[0] = REG_PACK_ISW(pack) ? 'W' : 'X';
        g_bp.reg_name[1] = (char)('0' + idx);
        g_bp.reg_name[2] = '\0';
        g_bp.reg_value = val;
    }

    /* 先激活状态机再布防，避免"已布防但 active=0"窗口内命中导致 SIGSEGV */
    g_hit_total = 0; /* 本轮布防的命中计数从 0 起 */
    diag_reset();
    g_bp.active = 1;
    __asm__ volatile("dmb ish" ::: "memory");
    if (pte_set_uxn(addr) != 0) {
        g_bp.active = 0;
        fn_mmput(mm);
        g_bp.mm = NULL;
        return -4;
    }
    LOG("prctl arm: tgid=%d addr=0x%lx reg=%s val=0x%lx", tgid, addr,
        g_bp.modify_reg ? g_bp.reg_name : "none", g_bp.reg_value);
    LOG("arm detail: pgd=0x%lx pte=0x%lx",
        (unsigned long)*(uint64_t *)((uintptr_t)g_bp.mm + mm_struct_offset.pgd_offset),
        (unsigned long)g_bp.pte_ptr);
    log_flush();
    return 0;
}

static int bp_disarm(pid_t tgid)
{
    if (!g_bp.active) return -1;
    if (tgid && g_bp.tgt_tgid != tgid) return -2;

    g_disarming = 1; /* 撤防收尾：残留单步由 step_hook 兜底吞掉 */
    pte_clear_uxn();
    /* 不主动清单步线程的 TIF/SS：那会制造"TIF 已清、硬件 SS 残留"的竞态，
     * 线程随后触发的单步异常会因 TIF 缺失而落到内核发 SIGTRAP。
     * 改为让单步线程自然走出：它下一次单步异常立刻进入 step_hook 兜底，
     * 由兜底完成"停单步+移出表项+吞陷阱"（一条指令内完成）。 */
    if (g_bp.mm) fn_mmput(g_bp.mm);
    g_bp.mm = NULL;
    g_bp.active = 0;
    LOG("prctl disarm: tgid=%d (stepping threads self-drain)", tgid);
    log_flush();
    return 0;
}

/* ======================= prctl hook 回调 ======================= */
static void before_prctl(hook_fargs8_t *fargs, void *udata)
{
    unsigned long opt = syscall_argn(fargs, 0);
    if (opt < PTE_PR_SET_BP || opt > PTE_PR_STATS) return;
    unsigned long a2 = syscall_argn(fargs, 1);
    unsigned long a3 = syscall_argn(fargs, 2);
    unsigned long a4 = syscall_argn(fargs, 3);
    unsigned long a5 = syscall_argn(fargs, 4);

    if (current_uid() != 0) { fargs->ret = (uint64_t)-1; fargs->skip_origin = 1; return; }

    long ret;
    switch (opt) {
    case PTE_PR_SET_BP: ret = bp_arm((pid_t)a2, a3, a4, a5); break;
    case PTE_PR_DEL_BP: ret = bp_disarm((pid_t)a2); break;
    case PTE_PR_PING:   ret = 0x10000; break;
    case PTE_PR_QUERY:  ret = (g_bp.active && (!a2 || g_bp.tgt_tgid == (pid_t)a2)) ? 1 : 0; break;
    case PTE_PR_STATS:  ret = (long)g_hit_total; break;
    default: return;
    }
    fargs->ret = (uint64_t)ret;
    fargs->skip_origin = 1;
}

/* ======================= KPM 入口 ======================= */
static long pte_kpm_init(const char *args, const char *event, void *__user reserved)
{
    LOG("init args=%s", args ? args : "(null)");

    if (resolve_symbols() != 0) {
        LOG("symbols fail");
        return 0;
    }

    if (detect_linear_voff() != 0) {
        LOG("linear voff fail");
        return 0;
    }

    hook_err_t err = hook_wrap3((void *)fn_do_mem_abort, before_do_mem_abort, after_do_mem_abort, NULL);
    if (err != HOOK_NO_ERR) {
        LOG("hook fail: %d", err);
        return 0;
    }
    g_hook_installed = 1;

    /* 注册用户态单步 hook：吞掉单步 SIGTRAP（内核标准扩展点） */
    g_step_hook.fn = step_hook_fn;
    fn_register_user_step_hook(&g_step_hook);
    g_hook_step_installed = 1;

    /* prctl 用户态交互接口（客户端模式） */
    err = fp_hook_syscalln(__NR_prctl, 5, before_prctl, NULL, NULL);
    if (err == HOOK_NO_ERR) {
        g_hook_prctl_installed = 1;
        LOG("prctl hook ok (client mode)");
    } else {
        LOG("prctl hook fail: %d", err);
    }

    /* 兼容加载参数模式：带参数则直接布防；否则等客户端命令 */
    if (args && args[0] && parse_args(args) == 0) {
        g_hit_total = 0;
        diag_reset();
        g_bp.active = 1;
        __asm__ volatile("dmb ish" ::: "memory");
        if (pte_set_uxn(g_bp.bp_addr) != 0) {
            LOG("arm fail");
            g_bp.active = 0;
        } else {
            LOG("armed ok (args mode)");
        }
    } else {
        LOG("client mode ready");
    }
    log_flush();
    return 0;
}

static long pte_kpm_ctl0(const char *args, char *__user out_msg, int outlen)
{
    (void)out_msg; (void)outlen;
    LOG("ctl0: %s", args ? args : "()");
    log_flush(); /* 运行期间把命中日志刷到 log.log */
    return 0;
}

static long pte_kpm_ctl1(void *a1, void *a2, void *a3)
{
    (void)a1; (void)a2; (void)a3;
    return 0;
}

static long pte_kpm_exit(void *__user reserved)
{
    LOG("exit");
    if (g_hook_prctl_installed) {
        fp_unhook_syscalln(__NR_prctl, before_prctl, NULL);
        g_hook_prctl_installed = 0;
    }
    /* 先撤防 + 清残留单步（此时 step hook 仍挂着，残留单步由它兜底吞掉），
     * 最后才卸 step hook。顺序颠倒会让"SS 已生效"窗口里的线程触发单步时
     * 落到内核 -> 目标进程收假 SIGTRAP。 */
    g_disarming = 1;
    pte_clear_uxn();
    for (int i = 0; i < MAX_STEP; i++) {
        if (!g_step_tids[i]) continue;
        struct task_struct *t = fn_find_task_by_vpid(g_step_tids[i]);
        if (t) {
            fn_user_disable_single_step(t);
            struct pt_regs *regs = task_pt_regs(t);
            if (regs) regs->pstate &= ~DBG_SPSR_SS;
        }
    }
    /* 短自旋让已在陷阱处理途中的线程完成（不依赖外部 sleep 符号） */
    for (int i = 0; i < 400 && step_tid_count() > 0; i++) {
        for (volatile int j = 0; j < 20000; j++)
            __asm__ volatile("yield");
    }
    for (int i = 0; i < MAX_STEP; i++) {
        g_step_tids[i] = 0;
        g_step_ext[i] = 0;
    }

    if (g_hook_step_installed) {
        safe_step_unlink();
        g_hook_step_installed = 0;
    }
    if (g_hook_installed) {
        hook_unwrap((void *)fn_do_mem_abort, before_do_mem_abort, after_do_mem_abort);
        g_hook_installed = 0;
    }
    if (g_bp.mm)
        fn_mmput(g_bp.mm);
    g_bp.mm = NULL;
    g_bp.active = 0;
    log_flush();
    return 0;
}

KPM_INIT(pte_kpm_init);
KPM_CTL0(pte_kpm_ctl0);
KPM_CTL1(pte_kpm_ctl1);
KPM_EXIT(pte_kpm_exit);