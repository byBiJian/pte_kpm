/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * pte_client.c - pte_kpm 用户态交互客户端（ARM64，参照 wxshadow_client 模式）
 * 通过 prctl 特殊 option 与内核 KPM 通信。
 * 编译：clang-21 --target=aarch64-linux-android24 --sysroot=$NDK/sysroot -static -O2 -o pte_client pte_client.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/prctl.h>

#define PTE_PR_SET_BP 0x50540001UL
#define PTE_PR_DEL_BP 0x50540002UL
#define PTE_PR_PING   0x50540003UL
#define PTE_PR_QUERY  0x50540004UL
#define PTE_PR_STATS  0x50540005UL

#define REG_NONE ((unsigned long)-1)
#define REG_PACK(idx, w) ((unsigned long)((idx) | ((w) ? 0x100UL : 0)))

static void usage(const char *prog)
{
    fprintf(stderr,
        "pte_client - pte_kpm 用户态交互客户端 (ARM64 PTE 断点)\n"
        "用法:\n"
        "  %s -p <pid|包名> -b <so> -o <偏移> [-r <X0..X8|W0..W8>=<值>]\n"
        "  %s -p <pid|包名> -a <绝对地址> [-r <reg>=<值>]\n"
        "  %s -p <pid|包名> -d    删除断点(-p 0 -d 强制撤防)\n"
        "  %s -p <pid|包名> -q    查询状态\n"
        "  %s -v                  ping(检测模块)\n"
        "  %s -s                  查询累计命中次数\n"
        "示例:\n"
        "  %s -p com.tencent.mf.uam -b libdemo.so -o 0x21F8F0 -r W8=2\n",
        prog, prog, prog, prog, prog, prog, prog);
    exit(1);
}

static int is_num(const char *s)
{
    if (!*s) return 0;
    for (; *s; s++) if (!isdigit((unsigned char)*s)) return 0;
    return 1;
}

static int find_pid(const char *pkg)
{
    DIR *d = opendir("/proc");
    if (!d) return -1;
    struct dirent *e;
    int found = -1;
    while ((e = readdir(d))) {
        if (!is_num(e->d_name)) continue;
        char path[64], buf[512];
        snprintf(path, sizeof(path), "/proc/%s/cmdline", e->d_name);
        int fd = open(path, O_RDONLY);
        if (fd < 0) continue;
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n <= 0) continue;
        buf[n] = '\0';
        if (!strcmp(buf, pkg)) { found = atoi(e->d_name); break; }
    }
    closedir(d);
    return found;
}

static unsigned long find_so_base(int pid, const char *so)
{
    char path[64], line[1024], perm[8], mapname[512];
    unsigned long start, end, off;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    unsigned long best = 0;
    size_t sl = strlen(so);
    while (fgets(line, sizeof(line), f)) {
        mapname[0] = 0;
        if (sscanf(line, "%lx-%lx %7s %lx %*s %*s %511s", &start, &end, perm, &off, mapname) < 5)
            continue;
        size_t ml = strlen(mapname);
        if (ml < sl) continue;
        if (strcmp(mapname + ml - sl, so)) continue;
        if (off == 0 && (best == 0 || start < best)) best = start;
    }
    fclose(f);
    return best;
}

static int parse_reg(const char *s, unsigned long *idx, int *is_w, unsigned long *val)
{
    char rn = (char)toupper((unsigned char)s[0]);
    if (rn != 'X' && rn != 'W') return -1;
    const char *eq = strchr(s, '=');
    if (!eq) return -1;
    long i = strtol(s + 1, NULL, 10);
    if (i < 0 || i > 8) return -1;
    *idx = (unsigned long)i;
    *is_w = (rn == 'W');
    *val = strtoul(eq + 1, NULL, 0);
    return 0;
}

int main(int argc, char **argv)
{
    const char *pkg = NULL, *so = NULL;
    unsigned long off = 0, abs_addr = 0;
    int do_del = 0, do_query = 0, do_ping = 0, do_stats = 0;
    unsigned long ridx = 0, rval = 0;
    int has_reg = 0, is_w = 0;

    int opt;
    while ((opt = getopt(argc, argv, "p:b:o:a:r:dqvs")) != -1) {
        switch (opt) {
        case 'p': pkg = optarg; break;
        case 'b': so = optarg; break;
        case 'o': off = strtoul(optarg, NULL, 0); break;
        case 'a': abs_addr = strtoul(optarg, NULL, 0); break;
        case 'r':
            if (parse_reg(optarg, &ridx, &is_w, &rval)) usage(argv[0]);
            has_reg = 1;
            break;
        case 'd': do_del = 1; break;
        case 'q': do_query = 1; break;
        case 'v': do_ping = 1; break;
        case 's': do_stats = 1; break;
        default: usage(argv[0]);
        }
    }

    if (do_ping) {
        long r = prctl((int)PTE_PR_PING, 0UL, 0UL, 0UL, 0UL);
        if (r == 0x10000) printf("pte_kpm loaded (v1.0.0)\n");
        else fprintf(stderr, "no pte_kpm, ret=%ld\n", r);
        return r == 0x10000 ? 0 : 1;
    }
    if (do_stats) {
        long r = prctl((int)PTE_PR_STATS, 0UL, 0UL, 0UL, 0UL);
        if (r >= 0) printf("hit_total=%ld\n", r);
        else fprintf(stderr, "stats fail: ret=%ld\n", r);
        return r >= 0 ? 0 : 1;
    }
    if (!pkg) usage(argv[0]);

    long lpid;
    if (do_del && is_num(pkg) && atol(pkg) == 0) {
        lpid = 0; /* -p 0 -d：强制撤防（内核忽略 tgid 校验） */
    } else {
        lpid = is_num(pkg) ? atol(pkg) : find_pid(pkg);
        if (lpid <= 0) { fprintf(stderr, "process not found: %s\n", pkg); return 1; }
    }

    if (do_query) {
        long r = prctl((int)PTE_PR_QUERY, (unsigned long)lpid, 0UL, 0UL, 0UL);
        printf("pid=%ld => %s (ret=%ld)\n", lpid, r == 1 ? "ARMED" : "not armed", r);
        return 0;
    }
    if (do_del) {
        long r = prctl((int)PTE_PR_DEL_BP, (unsigned long)lpid, 0UL, 0UL, 0UL);
        printf("pid=%ld del => %s (ret=%ld)\n", lpid, r == 0 ? "OK" : "FAIL", r);
        return r == 0 ? 0 : 1;
    }

    unsigned long addr = abs_addr;
    if (!addr) {
        if (!so) usage(argv[0]);
        unsigned long base = find_so_base((int)lpid, so);
        if (!base) { fprintf(stderr, "so not found in maps: %s (pid %ld)\n", so, lpid); return 1; }
        addr = base + off;
        printf("so base = 0x%lx, bp addr = 0x%lx\n", base, addr);
    }

    unsigned long pack = has_reg ? REG_PACK(ridx, is_w) : REG_NONE;
    long r = prctl((int)PTE_PR_SET_BP, (unsigned long)lpid, addr, pack, rval);
    if (r == 0) {
        printf("OK: pid=%ld bp=0x%lx", lpid, addr);
        if (has_reg) printf(", on hit set %c%lu=%lu (0x%lx)", is_w ? 'W' : 'X', ridx, rval, rval);
        printf("\n");
    } else {
        fprintf(stderr, "FAIL: set_bp ret=%ld\n", r);
    }
    return r == 0 ? 0 : 1;
}