/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * pte_kpm.h - ARM64 PTE 断点 KPM 核心定义
 * 仅用于网络安全研究，测试无 bug 后将开源到 GitHub。
 */
#ifndef _PTE_KPM_H_
#define _PTE_KPM_H_

#include <ktypes.h>
#include <kallsyms.h>
#include <kpmodule.h>
#include <ksyms.h>
#include <hook.h>
#include <log.h>
#include <kputils.h>
#include <common.h>
#include <pgtable.h>
#include <linux/string.h>
#include <asm/current.h>
#include <asm/thread_info.h>
#include <linux/list.h>
#include <linux/sched.h>
#include <linux/mm_types.h>
#include <linux/printk.h>
#include <linux/kernel.h>

/* mm_struct_offset / task_struct_offset 由 KernelPatch 提供 */
extern struct task_struct_offset task_struct_offset;
extern struct mm_struct_offset mm_struct_offset;

/* KPM 元信息 */
KPM_NAME("kpm-pte-breakpoint");
KPM_VERSION("1.0.0");
KPM_LICENSE("GPL v2");
KPM_AUTHOR("operit");
KPM_DESCRIPTION("ARM64 PTE UXN instruction breakpoint with register modification, no shadow page, no ghost page, no ptrace");

/* ---- 常量 ---- */
#define PAGE_SHIFT_4K 12
#define PAGE_SIZE_4K (1UL << PAGE_SHIFT_4K)
#define PAGE_MASK_4K (~(PAGE_SIZE_4K - 1))

/* ESR 常量（5.15 GKI arch/arm64/include/asm/esr.h 核实） */
#define ESR_ELx_EC_SHIFT 26
#define ESR_ELx_EC_MASK (0x3FUL << ESR_ELx_EC_SHIFT)
#define ESR_ELx_EC(esr) (((esr) & ESR_ELx_EC_MASK) >> ESR_ELx_EC_SHIFT)
#define ESR_ELx_EC_IABT_LOW 0x20
#define ESR_ELx_EC_DABT_LOW 0x24
#define ESR_ELx_EC_SOFTSTP_LOW 0x32
#define ESR_ELx_FSC 0x3F
#define ESR_ELx_FSC_TYPE 0x3C
#define ESR_ELx_FSC_PERM 0x0C

/* 调试单步常量（5.15 GKI arch/arm64/include/asm/debug-monitors.h 核实） */
#define DBG_MDSCR_SS (1UL << 0)
#define DBG_SPSR_SS (1UL << 21)
#define DBG_ESR_EVT(x) (((x) >> 27) & 0x7)
#define DBG_ESR_EVT_HWSS 0x1
#define DBG_HOOK_HANDLED 0
#define DBG_HOOK_ERROR 1

/* PTE_UXN 由 pgtable.h 提供 */

/* 断点槽位 */
#define MAX_BP 1

/* ---- prctl 交互协议（与 pte_client.c 一致）---- */
#define PTE_PR_SET_BP 0x50540001UL /* a2=tgid a3=addr a4=pack a5=value */
#define PTE_PR_DEL_BP 0x50540002UL /* a2=tgid */
#define PTE_PR_PING   0x50540003UL /* 返回 0x10000 */
#define PTE_PR_QUERY  0x50540004UL /* a2=tgid 返回 1=已布防 */
#define PTE_PR_STATS  0x50540005UL /* 返回累计命中次数 */
#define REG_NONE_PACK ((uint64_t)-1)
#define REG_PACK_IDX(p) ((int)((p) & 0xFF))
#define REG_PACK_ISW(p) (((p) & 0x100) != 0)

/* 参数解析 */
#define MAX_PKG_NAME 128
#define MAX_SO_NAME 128

/* 模块状态 */
typedef struct {
    int active;
    pid_t pid;
    pid_t tgt_tgid;              /* 目标线程组 id（数值化，避免解引用 task） */
    pid_t step_tid;              /* 最近进入单步的线程 tid（exit 清理用） */
    struct task_struct *task;
    struct mm_struct *mm;
    unsigned long bp_addr;       /* 目标虚拟地址（基址+偏移） */
    unsigned long bp_page;       /* 目标页地址 */
    uint64_t orig_pte;           /* 原始 PTE 值 */
    uint64_t *pte_ptr;           /* PTE 指针 */
    int armed;                   /* UXN 是否已设置 */
    int stepping;                /* 是否单步中 */
    int modify_reg;              /* 1=修改寄存器 */
    char reg_name[8];            /* X0..X8 / W0..W8 */
    uint64_t reg_value;          /* 修改后的值（64位） */
    unsigned long hit_pc;        /* 命中时 pc */
    unsigned long hit_lr;        /* 命中时 lr */
} bp_state_t;

/* ---- 符号类型定义 ---- */
typedef void *(*kallsyms_lookup_name_t)(const char *name);

typedef struct mm_struct *(*get_task_mm_t)(struct task_struct *task);
typedef void (*mmput_t)(struct mm_struct *mm);

#endif /* _PTE_KPM_H_ */